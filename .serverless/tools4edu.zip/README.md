<h1 align="center">Tools4Edu</h1>

<div align="center">
<a href="[https://tech4covid19.org/](https://tech4covid19.org/)" target="_blank"><img src="https://ucarecdn.com/e2cfb782-1524-496a-a48f-f97b75440d56/"></a>
</div>
<div align="center">
  <strong>Tools4Edu</strong>
</div>
<div align="center">
  Tools4Edu
</div>

<br />

<div align="center">
  <h3>
    <a href="https://tech4covid19.org">
      Website
    </a>
    <span> | </span>
    <a href="https://join.slack.com/t/tech4covid19/shared_invite/zt-csmcdobq-Qbn8fwG52JssqhrIwfv4Yg">
      Community
    </a>
  </h3>
</div>

<div align="center">
  <sub>Built with ❤︎ by the
  <a href="https://tech4covid19.org">tech4covid19.org</a> community
</div>
